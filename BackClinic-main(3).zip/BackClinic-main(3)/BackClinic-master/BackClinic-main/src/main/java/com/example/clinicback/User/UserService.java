package com.example.clinicback.User;

import com.example.clinicback.User.User;

public interface UserService {
    User save(UserDto userDto);
}
