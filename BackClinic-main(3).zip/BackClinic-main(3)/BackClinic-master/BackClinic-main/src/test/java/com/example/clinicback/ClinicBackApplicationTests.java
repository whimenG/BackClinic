package com.example.clinicback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan
@SpringBootTest
class ClinicBackApplicationTests {

    @Test
    void contextLoads() {
    }

}
